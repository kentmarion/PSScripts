#!C:\Python36\python
print("Content-type: text/html\n\n")

import subprocess
import requests
import codecs

#initialize API

#GET TOKEN
headers = {
    'accept': 'application/json',
    'Content-Type': 'application/json',
}

data = '{ "msid": "svc_myToken", "password": "Token123!"}'

response = requests.post("https://cloudops-api.optum.com/auth/login", headers=headers, data=data, verify=False)

resp = response.json()
myToken = resp["token"]

#PROCESS SERVERNAME TO QUERY

headers2 = {
    'accept': 'application/json',
    'X-API-KEY': myToken
}

# begin the table
#htmlfile = '<table class="table table-bordered">'
htmlfile = ''

# column headers

infile = open("hc_results.csv","r")

linecount = 0

for line in infile:
    if linecount == 0:
        linecount = linecount + 1
        continue

    line = line.replace('"','')
    row = line.split(",")
    vmname = row[0]
    cpu = row [1]
    memory = row[2]
    disk = row[3]
    uptime = row[4]
    poweredOn = row[5]
    TX = row[6]

    #ENV=PROD/STAGE/DEV/TEST
    baseURL = "https://cloudops-api.optum.com/api/vrops/prod/vm/"+vmname+"?resource_state=started"

    response = requests.get(baseURL, headers=headers2, verify=False)
    saveJSON = response.json()

    #print(response.status_code)

    vmstate = 1

    if response.status_code == 200:
        #DECAPSULATE
        vm_vrops_info = saveJSON["VM_VROPS_Info"]

        vm_info = vm_vrops_info[0]

        vm_info = vm_info["VM_Info"]

        moid = vm_info["Managed_Object_Ref"]
        vcenter = vm_info["Virtual_Center"]
        guest_tools_version = vm_info["Guest_Tools_Version"]
        guest_tools_status = vm_info["Guest_Tools_Status"]

        #print(moid)
        #print(vcenter)

        vmrcURL = "vmrc://"+vcenter+"/?moid="+moid
    else:
        vmstate = 0

#ROWS
    htmlfile += "<tr><td>"+vmname+"</td>"
    htmlfile += "<td>"+cpu+"</td>"
    htmlfile += "<td>"+memory+"</td>"
    htmlfile += '<td>'+disk+'<button type="button" class="btn btn-secondary btn-sm" style="float: right" disabled>Remediate</button></td>'
    htmlfile += "<td>"+uptime+"</td>"
    htmlfile += "<td>"+poweredOn+"</td>"
    htmlfile += "<td>"+TX+"</td>"
    htmlfile += "<td>"+guest_tools_version+"</td>"
    htmlfile += "<td>"+guest_tools_status+"</td>"

    #if linecount == 0:
    #    htmlfile+="<td>Console</td></tr>"
    if vmstate == 1:
        htmlfile += '<td><center><a href="'+vmrcURL+'"><button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal">Launch</button></a></center></td></tr>'
    else:
        htmlfile += '<td><center><button type="button" class="btn btn-success btn-sm" disabled>Launch</button></center></td></tr>'
    
    linecount = linecount + 1

# end the table
htmlfile +="</table>"
#print(htmlfile)

f=codecs.open("hc_success.html", 'r')
wrapper = f.read()

print(wrapper % (htmlfile))