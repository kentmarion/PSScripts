﻿ipmo VMware.PowerCLI

#GLOBALS
$username = "veasautoodi@ms.ds.uhc.com";
$password = "Hubget1t";

#Connect to VROPS
Connect-OMServer "vrops.uhc.com" -User $username -Password $password

#Define Server Name

$ServerPath = "C:\xampp\htdocs\hc\server_list.txt" 
$ServerList = Get-Content -Path $ServerPath

#Write-Output $ServerList

$allReports = [System.Collections.ArrayList]::new()

foreach($servername in $ServerList) {
    if($servername -eq ''){
        continue
    }

    $report = [pscustomobject]@{
        'Server' = $servername
        'CPU' = 'none'
        'Memory' = 'none'
        'Disk' = 'none'
        'Uptime' = 'none'
        'State' = 'none'
        'TX' = 'none'
    }
    
    try{
    #Check for vrops statkey
    #Get-OMResource 'wevrt80408' | Get-OMStat -Key "net|droppedTX_summation"
    #Get-OMResource 'wevrt80408' | Get-OMStatKey -Name "net|droppedRX_summation"

    #VROPSMETRICS

        $cpuave = [Math]::Round((Get-OMStat -Resource $servername -Key 'cpu|usage_average'| select value -last 1).value,2)
        $memave = [Math]::Round((Get-OMStat -Resource $servername -Key 'mem|usage_average'| select value -last 1).value,2)
        $uptimeDate = New-TimeSpan -Seconds (Get-OMStat -Resource $servername -Key 'sys|osuptime_latest'| select value -last 1).value | select days, hours, minutes, seconds
        $diskspace = [Math]::Round((Get-OMStat -Resource $servername -Key 'OnlineCapacityAnalytics|diskspace|capacityRemaining'| select * -last 1).value,2)
        $powerON = (Get-OMStat -Resource $servername -Key 'sys|poweredOn'| select value -last 1).value
        $TX = (Get-OMStat -Resource $servername -Key 'net|droppedTX_summation'| select value -last 1).value
    
        #RESULTS
   
        #Write-Output "Servername: $servername"
        #Write-Output "CPU: $cpuave%"
        #Write-Output "Mem: $memave%"
        #Write-Output "Disk: $diskspace GB Free"
        #Write-Output "Uptime: $($uptimeDate.days)D $($uptimeDate.hours)H $($uptimeDate.hours)M"

        $report.CPU = "$cpuave%"
        $report.Memory = "$memave%"
        $report.Disk = "$diskspace GB Free"
        $report.Uptime = "$($uptimeDate.days)D $($uptimeDate.hours)H $($uptimeDate.minutes)M"

        if($powerON -eq 1){
            #Write-Output "Status: Powered ON"
            $report.State = "Powered ON"
        }else{
           #Write-Output "Status: Powered OFF"
           $report.State = "Powered OFF"
        }

        $report.TX = $TX
        
    }catch{
     
        Write-Error "$servername not found"
    
    }finally{

        $null = $allReports.Add($report);
    }

} 

$allReports | Export-Csv -Path "C:\xampp\htdocs\hc\hc_results.csv" -NoTypeInformation

