#!C:\Python36\python
print("Content-type: text/html\n\n")

import cgi
import subprocess
import requests
import codecs
import os
from subprocess import call

form = cgi.FieldStorage()

server_list = form.getvalue('server_list')

server_list.rstrip()

#print(server_list)

f = open("server_list.txt", "w")
f.write(server_list)
f.close()

#os.system('powershell.exe C:\\xampp\\htdocs\\hc\\CombinedHCVROPS.ps1')


#call(['python','hc_table.py'])
