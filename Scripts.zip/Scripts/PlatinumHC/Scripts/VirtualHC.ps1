﻿param(
    [String]$server,
    [String]$vcenter
)
ipmo VMware.PowerCLI

$outpath = "C:\Users\mmend112\Documents\Scripts_PRB\PlatinumHC\Output\Report\Virtual_Report_PS.csv"

if($vcenter -like "mn*"){
    $username = 'MS\veasautoodi'
    $password = 'Hubget1t'
}else{
    $username = 'MS\veasauto'
    $password = 'Hubget1t'
}

Connect-VIServer -Server $vcenter -User $username -Password $password;

#CPU Hot Add Query
$CPUHotAdd = (Get-VM $server | 
Select ExtensionData).ExtensionData.config | 
Select CpuHotAddEnabled

#Direct Path IO Query
$DPIOVM = Get-VM $server | Get-NetworkAdapter
$DPIO_Status = $DPIOVM.ExtensionData.UptCompatibilityEnabled

#TimeSync Query
$VMView = Get-View -ViewType virtualmachine -Filter @{'name' = $server} 
$timesync = $VMView.Config.Tools.syncTimeWithHost

#CPU Socket
$socket = $VMView.config.hardware.NumCPU/$VMView.config.hardware.NumCoresPerSocket

#CPU Cores
$CPUCores = $VMView.config.hardware.NumCoresPerSocket

<##
$server | Select-Object @{N="Server";E={$server}},
     @{N="CPU Hot Add";E={$CPUHotAdd.CpuHotAddEnabled}}, 
     @{N="CPU Sockets";E={$socket}}, 
     @{N="Direct Path IO";E={$DPIO_Status}}, 
     @{N="Time Sync";E={$timesync}},
     @{N="vNUMA Status";E={$vNUMA_Setting}} |
 Export-CSV -Path $outpath -NoTypeInformation
 ##>

 
 $server | Select-Object @{N="Server";E={$server}},
     @{N="CPU Hot Add";E={
        if($CPUHotAdd.CpuHotAddEnabled -eq "TRUE"){
            $CPUHotAddStatus = "Enabled"
        }else{
            $CPUHotAddStatus = "Disabled"
        }
        $CPUHotAddStatus
     }}, 
     @{N="CPU Sockets";E={
        if($socket > 2){
            $socketstatus = "Non-Compliant"
        }else{
            $socketstatus = $socket
        }
        $socketstatus
     }}, 
     @{N="CPU Cores";E={$CPUCores}},
     @{N="Direct Path IO";E={
        if($DPIO_Status -eq "TRUE"){
            $DPIO_Status = "Enabled"
        }else{
            $DPIO_Status = "Disabled"
        }
        $DPIO_Status
     }}, 
     @{N="Time Sync";E={
        if($timesync -eq "TRUE"){
            $timesync = "Enabled"
        }else{
            $timesync = "Disabled"
        }
        $timesync
     }},
     @{N="vNUMA Status";E={
        if($CPUHotAdd.CpuHotAddEnabled -eq "TRUE"){
            $vNUMASetting = "Disabled"
        }else{
            $vNUMASetting = "Enabled"
        }
        $vNUMASetting
     }} | 
     Export-CSV -Path $outpath -NoTypeInformation

 #Write-Output $server
 #Write-Output $CPUHotAdd.CpuHotAddEnabled
 #Write-Output $socket
 #Write-Output $timesync
 #Write-Output $vNUMA_Setting