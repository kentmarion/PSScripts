﻿param(
    [String]$server = "wn000027964"
)

## Credentials and Output
$username = "MS\veasauto"
$password = "Hubget1t"
$outpath = "C:\Users\mmend112\Documents\Scripts_PRB\PlatinumHC\Output\Report\Windows_Report_PS.csv"

## diskspace
$diskspace = Invoke-Command $server -ScriptBlock {
    Get-CimInstance -ClassName Win32_LogicalDisk | 
    Select-Object -Property DeviceID,
    @{N = 'TotalSpace'; E = { [int]($_.Size / 1GB)}},
    @{N = 'FreeSpace'; E= { [int]($_.FreeSpace / 1GB) }},
    @{N = 'Utilization'; E= { 100 - (($_.FreeSpace/$_.Size)*100) }}
}


## diskspace > 90
$threshold = "NO"
foreach($disk in $diskspace){
    if($disk.Utilization -ge 90){
        $threshold = "YES"
        break
    }
}

$diskspace = $diskspace | Select-Object -Property DeviceID, FreeSpace | ConvertTo-JSON -Compress

## last boot time
$last_reboot = Invoke-Command $server -ScriptBlock {
    Get-WmiObject win32_operatingsystem | 
    select csname, 
    @{N=’LastBootUpTime’ ;E={$_.ConverttoDateTime($_.lastbootuptime)}}
}


## Windows os version
$OSVersion = (Get-WMIObject win32_operatingsystem -ComputerName $server).caption


## Ave CPU
$CPUAve = Get-WmiObject Win32_Processor -ComputerName $server | Measure-Object -Property LoadPercentage -Average | Select Average

## Ave Memory
$OS = gwmi -Class win32_operatingsystem -computername $server |
Select-Object @{Name = "MemoryUsage"; Expression = {"{0:N2}" -f ((($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)*100)/ $_.TotalVisibleMemorySize) }}

## Export CSV
$server | Select-Object @{N="Server";E={$server}},
     @{N="OS";E={$OSVersion}},
     @{N="CPU";E={"$($CPUAve.Average)%"}},
     @{N="Memory";E={"$($OS.MemoryUsage)%"}},
     @{N="Disk Space";E={$diskspace}}, 
     @{N="90% Disk Threshold";E={$threshold}}, 
     @{N="Last Reboot";E={$last_reboot.LastBootUpTime}} |
 Export-CSV -Path $outpath -NoTypeInformation
