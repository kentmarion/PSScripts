
import paramiko
import requests
import codecs
import os
import csv
from datetime import datetime
import time

start_time = time.time()

#CloudOps Creds
cloudops_user = 'veasauto'
cloudops_pass = 'Hubget1t'

#CloudOps API
cloudops_url = "https://cloudops-api.optum.com/auth/login"
cloudops_payload = '{"msid": "' + cloudops_user + '", "password": "' + cloudops_pass + '"}'
cloudops_headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
}

response = requests.post(cloudops_url, headers = cloudops_headers, data = cloudops_payload, verify = False)
response = response.json()

#Get CloudOps Token
cloudops_token = response['token']

#Prepare CSV
#Windows
win_headers = ["Server", "Environment", "Support Stage", "UCI/ODI", "CPU Hot Add", "CPU Socket", "CPU Cores", "DPIO Status", "TimeSync", "vNUMA Status", "OS Version", "CPU", "Memory", "Disk Space", "90% Threshold","Last Reboot"]
win_rows = []

#Linux
linux_headers = ["Server", "Environment", "Support Stage", "UCI/ODI", "CPU Hot Add", "CPU Socket", "CPU Cores", "DPIO Status", "TimeSync", "vNUMA Status", "Uptime", "OS Version", "File System Above 90% Threshold","kdump Status","SOS Report","Performance Snapshot","CPU", "Memory", "Boot Log Files in Error","NTP Status"]
linux_rows = []

#Cant Connect
error_headers = ["Server"]
error_rows = []

#Define Functions
def processWindows(server):
    path = "C:\\Users\\mmend112\\Documents\\Scripts_PRB\\PlatinumHC\\Scripts"
    os.chdir(path)
    os.system('powershell.exe .\WindowsHC.ps1 -server "' +server+ '"')
    
def processUnix(server):
    #print(server)

    username = "ai_st2" ## CHANGE TO SVC ACC IF POSSIBLE
    #username = "ralquer1"
    password = "A!$t2_2K21"

    f=codecs.open("C:\\Users\\mmend112\\Documents\\Scripts_PRB\\PlatinumHC\\Scripts\\LinuxHC2.txt", 'r')
    processUnix = f.read()
    f.close()
    
    command = processUnix
    ssh = paramiko.SSHClient()
    
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    connect_flag = 0

    try:
        ssh.connect(server,22, username, password)
    
        stdin, stdout, stderr = ssh.exec_command(command)

        output = stdout.read()
        output = str(output)
        output_list = output.split('==================\\n')

        connect_flag = 1


    except:
        connect_flag = 0
        output_list = ["Can't connect to server", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A"]
    
    finally:
        if connect_flag == 1:
            ## UPTIME
            output_list[0] = output_list[0].replace("b'",'').replace("days,",'').replace('\\n', '')

            if int(output_list[0]) > 30:
                output_list[0] = "Non-compliant"
            else:
                output_list[0] = "Compliant"

            ## OS Version
            output_list[1] = output_list[1].replace('\\n', '')

            ## FILE SYSTEM
            output_list[2] = output_list[2].replace('\\n','')

            if output_list[2] == '':
                output_list[2] = "None"

            ## KDUMP STATUS
            if 'Active: active' in output_list[3]:
                output_list[3] = "Installed"
            else:
                output_list[3] = "Not Installed"

            ## SOS REPORT
            if 'sos' in output_list[4]:
                output_list[4] = "Installed"
            else:
                output_list[4] = "Not Installed"

            ## Performance Snapshot
            output_list[5] = output_list[5].replace('\\n','; ')

            ## CPU
            output_list[6] = output_list[6].replace('\\n', '')

            ## Memory
            output_list[7] = output_list[7].replace('\\n', '')

            ## Boot Log Files
            output_list[8] = output_list[8].replace('\\n','')

            if output_list[8] == '':
                output_list[8] = "None"

            ## NTP
            output_list[9] = output_list[9].replace('\\n','; ').replace("'",'')


        linux_fields = []

        for key_value in output_list:
            linux_fields.append(key_value.replace('\\n', '\n').replace('\\t', '\t'))

        return linux_fields

def processVM(server,vcenter):
    path = "C:\\Users\\mmend112\\Documents\\Scripts_PRB\\PlatinumHC\\Scripts"
    os.chdir(path)
    os.system('powershell.exe .\VirtualHC.ps1 -server "' +server+ '" -vcenter "'+ vcenter +'"')

# GET SERVER LIST
server_list_file = codecs.open("C:\\Users\\mmend112\\Documents\\Scripts_PRB\\PlatinumHC\\servers.txt", 'r')
server_list = server_list_file.readlines()
server_list_file.close()

windows_count = 0
unix_count = 0
error_count = 0

for server in server_list:
    windows_flag = 0
    unix_flag = 0
    error_flag = 0

    #Start Loop Here
    #server = "wevrt80408"
    
    server = server.replace('\n', '').replace('\t', '')
    print("Processing server " + server)
    
    #Get VM Details
    cloudops_getvm_url = "https://cloudops-api.optum.com/api/itsm/cidetails/"+server
    cloudops_getvm_headers = {
      'X-API-KEY': cloudops_token
    }

    response = requests.get(cloudops_getvm_url, headers = cloudops_getvm_headers, verify = False)

    vrops_getvm_url = "https://cloudops-api.optum.com/api/vrops/prod/vm/"+server

    #Get Server Information
    if(response.status_code == 200):
        response = response.json()

        opsys = response['cidetails_itsm'][0]['os']
        os_ver = response['cidetails_itsm'][0]['os_version']
        server_env = response['cidetails_itsm'][0]['server_env']
        support_stage = response['cidetails_itsm'][0]['support_stage']
        virtual_flag = response['cidetails_itsm'][0]['virtualflag']

        #Get Server Type [Virtual/Physical]
        if virtual_flag:
            vrops_response = requests.get(vrops_getvm_url, headers = cloudops_getvm_headers, verify = False)

            if(vrops_response.status_code == 200):
                vrops_response = vrops_response.json()

                #Get vCenter
                vCenter = vrops_response['VM_VROPS_Info'][0]['VM_Info']['Virtual_Center']

                if "rz" in vCenter:
                    environment = "UCI"
                else:
                    environment = "ODI"

            else:
                error_count += 1
                error_fields = [server]
                error_rows.append(error_fields)

                environment = "N/A"
                continue

            processVM(server,vCenter)

            #RAW VM DATA, DONT USE AS FINAL OUTPUT
            vm_path = 'C:\\Users\\mmend112\\Documents\\Scripts_PRB\\PlatinumHC\\Output\\Report\\Virtual_Report_PS.csv'

            with open(vm_path) as csv_file:
                csv_reader = csv.reader(csv_file, delimiter=',')
                line_count = 0
                for row in csv_reader:
                    if line_count == 0:
                        line_count += 1
                        continue
                    else:
                        cpu_hotadd = row[1]
                        cpu_sockets = row[2]
                        cpu_cores = row[3]
                        dpio_status = row[4]
                        timesync_status = row[5]
                        vnuma = row[6]

            #vm_fields = [server, cpu_hotadd, cpu_sockets, dpio_status, timesync_status]
            #vm_rows.append(vm_fields)
        else:
            cpu_hotadd = "Physical"
            cpu_sockets = "Physical"
            cpu_cores = "Physical"
            dpio_status = "Physical"
            timesync_status = "Physical"
            environment = "UCI"
            
        #Get Operating System [Windows/UNIX]

        if "indows" in opsys:
            windows_flag = 1
            windows_count += 1

            processWindows(server)

            # RAW WINDOWS OUTPUT, DONT USE AS FINAL REPORT
            win_path = 'C:\\Users\\mmend112\\Documents\\Scripts_PRB\\PlatinumHC\\Output\\Report\\Windows_Report_PS.csv'

            with open(win_path) as csv_file:
                csv_reader = csv.reader(csv_file, delimiter=',')
                line_count = 0

                os_version = "N/A"
                os_version = "N/A"
                cpu_ave = "N/A"
                memory = "N/A"
                diskspace = "N/A"
                threshold = "N/A"
                uptime = "N/A"

                for row in csv_reader:
                    if line_count == 0:
                        line_count += 1
                        continue
                    else:
                        os_version = row[1]
                        cpu_ave = row[2]
                        memory = row[3]
                        diskspace = row[4]
                        threshold = row[5]
                        uptime = row[6]

            #win_fields = [server, os_version, cpu_ave, memory, diskspace, threshold, uptime]
            #win_rows.append(win_fields)
        
        else:
            unix_flag = 1
            unix_count += 1

            linux_metrics = processUnix(server)
            #linux_rows.append(linux_fields)
           
    else:
        error_count += 1
        error_flag = 1

        error_fields = [server]
        error_rows.append(error_fields)
        print("Server not Found in CMDB.")
        continue

    if windows_flag == 1:
        win_fields = [server, server_env, support_stage, environment, cpu_hotadd, cpu_sockets, cpu_cores, dpio_status, timesync_status, vnuma, os_version, cpu_ave, memory, diskspace, threshold, uptime]
        win_rows.append(win_fields)

    else:
        linux_fields = [server, server_env, support_stage, environment, cpu_hotadd, cpu_sockets, cpu_cores, dpio_status, timesync_status, vnuma]
        
        for metric in linux_metrics:
            linux_fields.append(metric)

        linux_rows.append(linux_fields)

    #gen_fields = [server, server_env, support_stage, environment]
    #gen_rows.append(gen_fields)

    ## LOOP ENDS HERE

## EXPORT FINAL REPORT
#Get Current Time
now = datetime.now()
current_time = now.strftime("%H_%M_%S")

#Windows
if windows_count != 0:
    win_filename = "C:\\Users\\mmend112\\Documents\\Scripts_PRB\\PlatinumHC\\Output\\Win_Report_" +current_time+ ".csv"
    with open(win_filename, 'w', newline='', encoding='utf-8') as csvfile: 
        # creating a csv writer object 
        csvwriter = csv.writer(csvfile) 
        
        # writing the headers
        csvwriter.writerow(win_headers) 
        
        # writing the data rows 
        csvwriter.writerows(win_rows)

#Linux
if unix_count != 0:
    linux_filename = "C:\\Users\\mmend112\\Documents\\Scripts_PRB\\PlatinumHC\\Output\\Unix_Report_" +current_time+ ".csv"
    with open(linux_filename, 'w', newline='', encoding='utf-8') as csvfile: 
        # creating a csv writer object 
        csvwriter = csv.writer(csvfile) 
        
        # writing the headers 
        csvwriter.writerow(linux_headers) 
        
        # writing the data rows 
        csvwriter.writerows(linux_rows)

#Error
if error_count !=0:
    error_filename = "C:\\Users\\mmend112\\Documents\\Scripts_PRB\\PlatinumHC\\Output\\Error_Report_" +current_time+ ".csv"
    with open(error_filename, 'w', newline='', encoding='utf-8') as csvfile: 
        # creating a csv writer object 
        csvwriter = csv.writer(csvfile) 
        
        # writing the headers 
        csvwriter.writerow(error_headers) 
        
        # writing the data rows 
        csvwriter.writerows(error_rows)



print("--- %s seconds ---" % (time.time() - start_time))