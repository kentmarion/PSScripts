﻿$computernames = Get-Content -Path "c:\temp\powershell\computernames.txt"

Invoke-Command -ComputerName $computernames -ScriptBlock{

$getEvent = Get-WinEvent -LogName System -ErrorAction SilentlyContinue | Where { ($_.Id -eq '1177') -or ($_.Id -eq '1135') -or ($_.Id -eq '1127')}

Get-Cluster | select PSComputerName, Name, *subnet*, 
    @{N='Event Count'; E={$getEvent.Count}},
    @{N='Dates'; E={
        foreach ($date in $getEvent.TimeCreated){
            Write-Output $date`r`n
        }
    }}
} | Export-CSV -Path "c:\temp\powershell\report.csv" -NoTypeInformation