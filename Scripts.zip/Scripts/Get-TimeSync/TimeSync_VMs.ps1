﻿$CurrentDate = Get-Date
$CurrentDate = $CurrentDate.ToString('MM-dd-yyyy_hh-mm-ss')
$output = "C:\Users\MMEND111\OneDrive - UHG\Scripts\Get_TimeSync_VMs\Output\" + "TimeSync_" + $CurrentDate + ".csv"

$username = 'MS\veasautoodi'
$password = 'Hubget1t'

Connect-VIServer mn053h1b2.uhc.com -User $username -Password $password

$VMs = Get-VM

foreach ($VM in $VMs){
    
    $os = $VM.Guest.OSFullName

    if($os -like "*Windows*"){
        Write-Output "Processing $VM";
        $VMView = Get-View -ViewType virtualmachine -Filter @{'name' = $VM.Name} 
        $TimeSync = $VMView.Config.Tools.syncTimeWithHost

        $query = Get-VM $VM | Select Name, @{N="OS";E={$os}}, @{N="Time Sync";E={$TimeSync}};

        $query | Export-CSV -Path $output -NoTypeInformation -Append;
    }
}

## HELLO WORLD
## THIS IS MARION