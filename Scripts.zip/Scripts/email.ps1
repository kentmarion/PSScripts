﻿#---------------------------- FUNCTION MAIL-LOG -----------------------------

# Takes in the log file to be mailed and the list of recipients,
# then sends the log file as an attachment to this list.

function mail-Log ($addressList)
{
	foreach ($mailRecipient in $addressList)
	{
        
		$timestamp = Get-Date

		# Only Change These Variables
		$subject = "CyberARK Validation Requirements"
		$signature = "`n`nMessage sent via PowerShell Script at $($timestamp.ToString('u')).  `n`nFor questions about this log file, contact Ronilo Cornejo <ronilo_cornejo@optum.com>"
		$body = "Hello, `n`nThis message contains the result file for CyberArk Validation.`n$signature"
		
		# Add log file as attachment
		#$attachment = <path of attachment>
		
		# Send
        # Remove comment at the end of line 23 for if there are attachments.
		Send-MailMessage -From "donotreply_vmwareservices@optum.com" -To $mailRecipient -Subject $subject -Body $body -SmtpServer mail20.corpmailsvcs.com #-Attachments $logfile
        write-output "Message sent to $mailRecipient."
	}
}

#=========================== MAIN PROCESSING SECTION ============================ 

# Mail log file
$addressList = "marion_paul_mendoza@optum.com" #separate with comma if multiple emails

mail-Log $addressList
write-output "Mailing complete."