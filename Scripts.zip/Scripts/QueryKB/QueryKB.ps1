﻿$creds = Get-Credential
$KBUpdate = Read-Host "Please enter KB to be queried: "
$dateToday = Get-Date -Format "MM_dd_yyyy-HH_mm_ss"
$outFile = ".\Output\" + $KBUpdate +"_" + $dateToday + ".csv"
$servers = Get-Content ".\servers.txt"

foreach($server in $servers){
    
    $status = ""

    Write-Output "Processing $server"

    $remoteQuery = Invoke-Command -ComputerName $server -Credential $creds -ScriptBlock{

        $Session = New-Object -ComObject "Microsoft.Update.Session"
        $Searcher = $Session.CreateUpdateSearcher()

        $historyCount = $Searcher.GetTotalHistoryCount()

        $result = $Searcher.QueryHistory(0, $historyCount) | Select-Object Title, Description, Date,

            @{name="Operation"; expression={switch($_.operation){

                1 {"Installation"}; 2 {"Uninstallation"}; 3 {"Other"}

        }}}

        Write-Output $result.Title

    }

    #Write all Installed KBs
    #Write-Output $remoteQuery

    if($remoteQuery -like "*$KBUpdate*"){
        $status = "Installed"
        Write-Output "Installed"
    }else{
        $status = "Not-Installed"
        Write-Output "Not-Installed"
    }

    $KBUpdate | select @{N="Server";E={$server}}, @{N="Status";E={$status}} |
    Export-CSV -Path $outFile -NoTypeInformation -Append
}




<############################################
KBS:

KB5008218

Windows Server 2022: KB5010197
Windows Server 2019: KB5010196
Windows Server 2016: KB5010195
Windows Server 2012 R2: KB5010215
#########################################>
