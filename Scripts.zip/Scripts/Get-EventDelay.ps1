﻿$computernames = Get-Content -Path "c:\temp\powershell\computernames.txt"

Invoke-Command -ComputerName $computernames -ScriptBlock{
Get-Cluster | select PSComputerName, Name, *subnet*, @{N='Event Count'; E={(Get-WinEvent -LogName System -ErrorAction SilentlyContinue | Where { ($_.Id -eq '1177') -or ($_.Id -eq '1135') -or ($_.Id -eq '1127')}).Count}} 
} | Export-CSV -Path "c:\temp\powershell\report.csv" -NoTypeInformation