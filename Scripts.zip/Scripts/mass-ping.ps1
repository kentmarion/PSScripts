﻿$complist = Get-Content "C:\Users\MMEND111\OneDrive - UHG\Scripts\ping-server.txt"
foreach($comp in $complist){
    
    $pingtest = Test-Connection -ComputerName $comp -Quiet -Count 1 -ErrorAction SilentlyContinue
    if($pingtest){
         Write-Host($comp + " is online")
     }
     else{
        Write-Host($comp + " is not reachable")
     }
     
}