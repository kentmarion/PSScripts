﻿ipmo VMWare.PowerCLI

#GLOBALS
$username = "fescalon@ms.ds.uhc.com";
$password = "HAL:.L9d";

$root = "C:\Users\MMEND111\OneDrive - UHG\Scripts\VMRC"
$CORE = "$($root)\CORE.csv" 
$ODI = "$($root)\ODI.csv"

#Write-Output $ODI;

Connect-OMServer "vrops.uhc.com" -User $username -Password $password

$hostname = Read-Host -Prompt "Enter VM Hostname" #TEST CORE: wtvep50921 ODI: wn000027964

#Error check if VM exists
try{
    #$ErrorActionPreference = "Stop" #Make all errors terminating
    $resource = Get-OMResource $hostname -ErrorAction Stop| select @{L=’MOID’;E={$_.SolutionObjectID}}, Health, ResourceKind

} catch {
    Write-Output "VM not found"

    #Stops the script
    #exit

}

Write-Output ""
Write-Output "VM:" $hostname
Write-Output $resource

$MOID = $resource.MOID
$health = $resource.Health
$kind = $resource.ResourceKind

if($health -eq "Green" ){

    if($kind -eq "VirtualMachine"){
        Write-Output "Connecting to VMRC now..."

        #Checks if server is CORE or ODI
        if($hostname.length -gt 10){
            $vCenters = Import-CSV $ODI

        }else{
            $vCenters = Import-CSV $CORE
        }

        #CONNECT TO vCENTER AND QUERY
        foreach ($vCenter in $vCenters){
            $vCenter = $vCenter.vCenter+".uhc.com";
            #Write-Output $vCenter;
            Connect-VIServer $vCenter -User "MS\fescalo5" -Password "bHPt6*Ui"

            #CHECK IF VM is IN VCENTER
            try{
                $flag = $true;
                $getvm = Get-VM $hostname -ErrorAction Stop;

            }catch{
                $flag = $false;
            }

            #Write-Output $flag;

            if($flag -eq $true){
               $correctvCenter = $vCenter;
               Write-Output "vCenter found:" $correctvCenter
               $vmrc = "vmrc://"+$correctvCenter+"/?moid="+$MOID
           
               #OPEN URL in browser to OPEN VRMC
               Start-Process $vmrc 
               break
            }    
          
        }

    }else{
       Write-Output "Input is not a VM...Stopping Script"
       break 
    }

}else {
    Write-Output "VM status is not Green, unable to connect VMRC. Stopping script."
    break
    #exit
}
