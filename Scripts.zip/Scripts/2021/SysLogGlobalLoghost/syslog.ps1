﻿ipmo VMWare.powercli

$username = "MS\odiprdrmd_sa"
$password = "@sakab0y#1"

#$currvCenter = "mn011h1a2.uhc.com"

#Connect-VIServer -Server $currvCenter -username $username -Password $password

#$currHost = "mn011-5hz1-06s39.uhc.com"

$tnt = "udp://sa-syslog.uhc.com:514,udp://vrli-np.uhc.com:514"
$elr = "udp://sa-syslog.uhc.com:514,udp://vrli-ctc-rc3.uhc.com:514"
$ctc = "udp://sa-syslog.uhc.com:514,udp://vrli-elr.uhc.com:514"

$csv = Import-Csv "C:\Users\MMEND111\OneDrive - UHG\Scripts\SysLogGlobalLoghost\Finding_EsxRemoteSysLogRule_06-08-2021_ODI.csv";
$currVCenter = "";

foreach ($line in $csv)
{
    $newVCenter = $line.vCenter;
    $currHost = $line.host;

    if($newVCenter -ne $currVCenter){
      
        Connect-VIServer -Server $newVCenter -User $username -Password $password;
        $currVCenter = $newVCenter;

        Write-Output connected to vCenter $currVCenter;
    }

    Get-AdvancedSetting -Entity (Get-VMHost $currHost) -Name Syslog.global.logHost | Set-AdvancedSetting -Value $ctc -Confirm:$false
    
}