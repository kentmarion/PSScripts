﻿$CurrentDate = Get-Date
$CurrentDate = $CurrentDate.ToString('MM-dd-yyyy_hh-mm-ss')

$csv = Import-Csv "C:\Users\MMEND111\OneDrive - UHG\Scripts\SysLogGlobalLoghost\Syslog.csv";

$output = "C:\Users\MMEND111\OneDrive - UHG\Scripts\SysLogGlobalLoghost\Syslog_Uptime" + "_" + $CurrentDate + ".csv"
$currVCenter = "";

foreach ($line in $csv)
{
    $newVCenter = $line.vCenter;
    $currHost = $line.host;

    Write-Output $newvCenter;
    Write-Output $currHost;

    ###Checks which creds to use####
    #CHANGE UR CREDS BEFORE RUNNING#
    if($vCenter -like "mn0*") {
        #ODI CREDS
        $username = "MS\mmend133";
        $password = "s*Kg5AqQ";
    }else{
        #SECONDARY CREDS
        $username = "MS\mmend112";
        $password = '$VWU3Ni:';
    }
    ###############################

    if($newVCenter -ne $currVCenter){
        Connect-VIServer -Server $newVCenter -User $username -Password $password;
        $currVCenter = $newVCenter;
    }

    $query = Get-VMHost $currHost | Select @{N="vCenter"; E={$vCenter}}, Name,
  @{N="Uptime"; E={New-Timespan -Start $_.ExtensionData.Summary.Runtime.BootTime -End (Get-Date) | Select -ExpandProperty Days}}

      #Export query and appending them to the new report
    $query | Export-CSV -Path $output -NoTypeInformation -Append;
}
