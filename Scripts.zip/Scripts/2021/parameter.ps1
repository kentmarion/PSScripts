﻿param(
    [string]$word = ""
)

Write-Output "You have entered:"
Write-Output $word;

