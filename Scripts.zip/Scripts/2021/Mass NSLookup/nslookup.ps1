﻿#Prepare your CSV with "hostname" as the heading for the column.
$csv = Import-Csv "C:\Users\MMEND111\OneDrive - UHG\Scripts\Mass NSLookup\hostname.csv";

$allReports = [System.Collections.ArrayList]::new()

foreach ($line in $csv)
{
    $report = [pscustomobject]@{
                'ComputerName' = $line.hostname
                'IPAddress' = 'none'
                'Status' = 'none'
                }

    try{
        $hostname = $line.hostname;

        $dns = Resolve-DnsName $hostname -ErrorAction Stop | Select -First 1
        $report.ComputerName = $dns.Name
        $report.IPAddress = $dns.IPAddress
        $report.Status = 'ok'
    }catch{
        
        Write-Error "$hostname not found"

    }finally{
        $null = $allReports.Add($report);
    }
}

$allReports | Export-Csv -Path "C:\xampp\htdocs\hc\hc_results.csv" -NoTypeInformation

