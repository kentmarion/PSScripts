﻿$CurrentDate = Get-Date
$CurrentDate = $CurrentDate.ToString('MM-dd-yyyy_hh-mm-ss')

#CHANGE#
$csv = Import-CSV "C:\Users\MMEND111\OneDrive - UHG\Scripts\NE-007\NE-007_v1.0.csv" 
$output = "C:\Users\MMEND111\OneDrive - UHG\Scripts\NE-007\Output\VM_Portgroup" + "_" + $CurrentDate + ".csv"
########


foreach ($line in $csv)
{
    $newVCenter = $line.vCenter;
    

    #Check which creds to use
    if($vCenter -like "mn0*") {
        #ODI CREDS
        $username = "MS\veasautoodi"; 
        $password = 'Hubget1t';    
    }else{
        #SECONDARY CREDS
        $username = "MS\veasauto"; 
        $password = "Hubget1t";    
    }

    $newVCenter = $line.vCenter;
    $currHost = $line.host;

    Write-Output $newvCenter;
    Write-Output $currHost;

    if($newVCenter -ne $currVCenter){
        Connect-VIServer -Server $newVCenter -User $username -Password $password;
        $currVCenter = $newVCenter;
    }

    
    #Perform queries
    try{
        Get-VirtualPortGroup -VMHost $currHost | 
        Where-Object {$_.Name -like "vMotion*" -or $_.Name -eq "management_network" -or $_.Name -like "vsg_vlan_*"} | 
        ForEach-Object {
            $pg_name = $_.Name

            $pg = Get-View -ViewType Network -Property Name,VM -Filter @{Name=$pg_name}

            $result = Get-View -Id $pg.Vm -Property Name | 
            Select-Object @{Name='vCenter';Expression={$currVCenter}},
            @{Name='Host';Expression={$currHost}},
            @{Name='Portgroup';Expression={$pg_name}},
            Name

            $result | Export-CSV -Path $output -NoTypeInformation -Append;

        }

        
    }catch{

        Write-Output ""

    }
        
}



