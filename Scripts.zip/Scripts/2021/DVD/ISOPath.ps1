﻿$username = "MS\mmend112";
$password = 'Tjd_x0IM';
$outpath = "C:\Users\MMEND111\OneDrive - UHG\Scripts\DVD\output_cd_dvd.csv"
$csv = Import-Csv "C:\Users\MMEND111\OneDrive - UHG\Scripts\DVD\cd_dvd.csv";


#########################################
$currVCenter = "";

foreach ($line in $csv)
{
    $newVCenter = $line.vCenter;
    $currVM = $line.vm;

    Write-Output $newVCenter;
    Write-Output $currVM;

    if($newVCenter -ne $currVCenter){
        Connect-VIServer -Server $newVCenter -User $username -Password $password;
        #Connect-VIServer -Server rz001mn011v2gc.uhc.com -User $username -Password $password;
        $currVCenter = $newVCenter;
    }

    $results = Get-VM $currVM | Get-CDDrive | Select @{N="vCenter";E={$currVCenter}},@{N="VM";E={$_.Parent.Name}},IsoPath, ConnectionState;
    #$results = Get-VM $currVM | Get-CDDrive | Where {$_.IsoPath} | Select *;
    Write-Output $results;
    $results | Export-CSV $outpath -Append -NoTypeInformation;
}


