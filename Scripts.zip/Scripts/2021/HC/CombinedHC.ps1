﻿################################################################################# 
## Uptime and Capacity Server Health Check 
## This scripts check the server Avrg CPU and Memory utlization along with C drive 
## disk utilization and sends an email to the receipents included in the script
################################################################################ 

$ExcludeServices = @('RemoteRegistry','DoSvc','edgeupdate','gpsvc','IntelAudioService','sppsvc')
$UptimeCheck = 24

$ServerListFile = ".\ServerList.txt"  
$ServerList = Get-Content $ServerListFile -ErrorAction SilentlyContinue 



ForEach($computername in $ServerList) 
{

$computername = $computername.Trim()
$AVGProc = Get-WmiObject -computername $computername win32_processor | 
Measure-Object -property LoadPercentage -Average | Select Average
$OS = gwmi -Class win32_operatingsystem -computername $computername |
Select-Object @{Name = "MemoryUsage"; Expression = {"{0:N2}" -f ((($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)*100)/ $_.TotalVisibleMemorySize) }}
$vol = Get-WmiObject -Class win32_Volume -ComputerName $computername -Filter "DriveLetter = 'C:'" |
Select-object @{Name = "C PercentFree"; Expression = {"{0:N2}" -f  (($_.FreeSpace / $_.Capacity)*100) } }
$lastboot = Get-WmiObject -ComputerName $computername -Query "SELECT LastBootUpTime FROM Win32_OperatingSystem"
$uptime = (Get-Date) - $lastboot.ConvertToDateTime($lastboot.LastBootUpTime)
$uptimestr = "$($uptime.days)d $($uptime.hours)h $($uptime.Minutes)m"
$services = (Get-Service | Where-Object {$_.Status -eq "Stopped" -and $_.StartType -eq "Automatic" -and $_.Name -notin  $ExcludeServices} | Select-Object -ExpandProperty Name) -join ","

$result += [PSCustomObject] @{ 
        ServerName = "$computername"
        CPULoad = "$($AVGProc.Average)%"
        MemLoad = "$($OS.MemoryUsage)%"
        CDrive = "$($vol.'C PercentFree')%"
        Uptime = "$($uptimestr)"
        Services = "$($services)"
    }

    $Outputreport = "<HTML><TITLE> Server Health Report </TITLE>
                     <BODY background-color:peachpuff>
                     <font color =""#99000"" face=""Microsoft Tai le"">
                     <H2> Server Health Report </H2></font>
                     <Table border=1 cellpadding=0 cellspacing=0>
                     <TR bgcolor=gray align=center>
                       <TD><B>Server Name</B></TD>
                       <TD><B>Avrg.CPU Utilization</B></TD>
                       <TD><B>Memory Utilization</B></TD>
                       <TD><B>C Drive Utilization</B></TD>
                       <TD><B>Uptime</B></TD>
                       <TD><B>Services</B></TD></TR>"
                        
    Foreach($Entry in $Result) 
    
        { 
          if(($Entry.CpuLoad -lt 90) -and ($Entry.memload -lt 90) -and ([string]::IsNullOrWhiteSpace($services) -eq "True") -and ($uptime.TotalHours -lt $UptimeCheck))
          { 
            $Outputreport += "<TR bgcolor=green>" 
          } 
          elseif (($Entry.CpuLoad -gt 95) -and ($Entry.memload -gt 95))
           {
            $Outputreport += "<TR bgcolor=yellow>" 
          } else {
            $Outputreport += "<TR bgcolor=red>" 
          }
          $Outputreport += "<TD>$($Entry.Servername)</TD><TD align=center>$($Entry.CPULoad)</TD><TD align=center>$($Entry.MemLoad)</TD><TD align=center>$($Entry.Cdrive)</TD>
          <TD align=center>$($uptimestr)</TD><TD align=center>$($Entry.Services)</TD></TR>" 
        }
     $Outputreport += "</Table></BODY></HTML>" 
        } 
 
$Outputreport | out-file .\Test.htm 
Invoke-Expression .\Test.htm
##Send email functionality from below line, use it if you want   

exit

$smtpServer = "yoursmtpserver.com"
$smtpFrom = "fromemailaddress@test.com"
$smtpTo = "receipentaddress@test.com"
$messageSubject = "Servers Health report"
$message = New-Object System.Net.Mail.MailMessage $smtpfrom, $smtpto
$message.Subject = $messageSubject
$message.IsBodyHTML = $true
$message.Body = "<head><pre>$style</pre></head>"
$message.Body += Get-Content C:\scripts\test.htm
$smtp = New-Object Net.Mail.SmtpClient($smtpServer)
$smtp.Send($message)
