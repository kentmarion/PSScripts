﻿#Script location labe99144

cls
write-output "$(Get-Date): Script started!"
<#==============================================================================
# SCRIPT PURPOSE: To loop through an inventory of servers provided in a CSV
# and update the uht-Cyberark-AutoDetect Active Directory attribute
# for each server. The attribute value set by the script for each server
# depends on the operating system of that server, unless a single attribute
# is specified by the user. For each attempted attribute update,
# the script will log successes and failures, emailing the log file
# to a list of addresses specified as a parameter.
#
# CREATE DATE: 7-29-16
# CREATE AUTHOR(S): Asim Chaudhary <asim_chaudhary@optum.com>
# LAST MODIFY DATE: 12-8-16
# LAST MODIFY AUTHOR: (asim_chaudhary@optum.com)
# RUN SYNTAX: .\updateAD-Cyberark-AutoDetect-Master.ps1
#
###########################################################################################################################################
Attribute Values Table



Domain Operating System AD attribute value for Auto-Query AD attribute value for Auto-Query
(to Onboard accounts) (to Decomm accounts)



MS Windows Cyberark-O Cyberark-D
MS Unix/Linux Cyberark-UNO Cyberark-UND
MS ESX Cyberark-ENO Cyberark-END

DMZ Windows Cyberark-O Cyberark-D
DMZ Unix/Linux Cyberark-UDO Cyberark-UDD
DMZ ESX Cyberark-EDO Cyberark-EDD



###########################################################################################################################################
#
# SPECIAL REQUIREMENTS: 1. Run this script from a server containing
# the active directory module. I (Joel) have been using labe99144.
#
# 2. The logfile will be created in the temp folder at c:\temp\ADcyberark\updateADlog.csv.
# Be sure that this directory exists and that the user has write access to this location.
#
# 3. The mail-log function in the script currently sends a message
# from asim_chaudhary@optum.com using SmtpServer mail20.corpmailsvcs.com.
# If a different user runs this script, he/she may wish to change
# the email address and server hardcoded in the mail-log function.
#
# PARAMETERS: 1. CSV file containing a column entitled netBiosName.
# The netBiosName column should contain the list of servers
# for which the Active Directory attribute should be updated.
#
# 2. Txt file containing a list of email addresses
# that should receive a copy of the log file exported by the script.
#
# 3. (Optional) uht-Cyberark-AutoDetect Active Directory value.
# if not given, script will attempt to set values based on the type
# of each server specified in the input csv.
#
# OUTPUT: 1. Comma-separated log file of successful and unsuccessful updates.
#
# NOTES: 1. Items listed as special requirements could be refactored
# as the following parameters: email address, email server, log file location.
#
# 2. If the optional parameter is not given, the script will skip processing
# any server for which the domain or OS cannot be determined.
# This means the user has a better chance of setting the AD attribute for a
# list of servers, if the list of servers contains only servers that should
# be set to a single attribute, and that attribute is specified as a parameter.
#
#------------------------------------------------------------------------------
# Revision History
#------------------------------------------------------------------------------
#
# VERSION: 1.0
# REVISION DATE: 7-29-16
# REVISION AUTHOR: Asim Chaudhary
# REVISION COMMENTS: Initial version
# Dev
#
# VERSION: 2.0
# REVISION DATE: 8-5-16
# REVISION AUTHOR: Asim Chaudhary
# REVISION COMMENTS: Ready for testing
# Test
#
# VERSION: 3.0
# REVISION DATE: 10-6-16
# REVISION AUTHOR: Asim Chaudhary
# REVISION COMMENTS: Master Script
# Consolidated all attribute types
# Ready for prod
#
# VERSION: 3.1
# REVISION DATE: 12-8-16
# REVISION AUTHOR: Asim Chaudhary
# REVISION COMMENTS: Master Script
# Added DMZ environment option
# Ready for prod
#
# VERSION: 3.2
# REVISION DATE: 02-28-2019
# REVISION AUTHOR: Asim Chaudhary
# REVISION COMMENTS: Added $PSScriptRoot to remove dependency on the path. Now only need to provide the file name which needs to
# saved in same directory as the script.
#
# Ready for prod
#==============================================================================
#============================Initialization Section============================#>



# Set Error Preference
$ErrorActionPreference = "SilentlyContinue"
$error.clear()



# Import Active Directory module
Import-Module ActiveDirectory
$workingDirectory = $PSScriptRoot
# Clear old log file; Create new log file with a header
#$logFile = "c:\temp\ADCyberark\updateADlog.csv"
$logFile = "$workingDirectory\updateADlog.csv"



Remove-Item $logFile -ErrorAction SilentlyContinue
$Header = "time,server,CanonicalName,message,value"
Add-Content -Value $Header -Path $logFile



# Take in a csv file containing a list of servers under the column: netBiosName.
# test path: c:\temp\ADCyberark\test.csv
$serverInfoInput = ""
$inputFileName = Read-Host "Enter sever list CSV file for bulk update"
$serverInfoInput = "$workingDirectory\$inputFileName"



# Check input before proceeding.
if ($serverInfoInput -ne "")
{
# Check that the CSV file exists.
$serverInfoInput = $serverInfoInput.Trim()
if (!(Test-Path -PathType Leaf -Path $serverInfoInput))
{
Write-Warning "Bad CSV input."
return "Script Terminated. Try running again."
}
$serverInven = Import-Csv $serverInfoInput
}



# Take in a text file containing a list email addresses that
# should receive the log file exported by this script.
# test path: c:\temp\ADCyberark\emailList.txt
$addressListInput = ""
$InputaddressList = Read-Host "Enter text file name containing email list for sending log file"
$addressListInput = "$workingDirectory\$InputaddressList"
# Check input before proceeding.
If ((Get-Content $addressListInput) -eq $Null)
{
Write-Warning "Bad txt file input."
return "Script Terminated. Try running again."
}
$addressList = Get-Content $addressListInput



# Allow user to choose if he/she wishes to set all servers
# to a single value, or if the script should decide based on server type.
$singleValue = ""
$singleValue = Read-Host "To set all servers in the input csv to a single value, enter that value here; otherwise, press enter to allow the script to set the AD attribute value for each server in the input based on the type of each server"



if ($singleValue -eq "")
{
write-warning "Because the script has been charged with deciding the attribute value for each server, if the script is unable to detect the domain or OS for a given server, it will skip that server and go to the next. This will be reflected in the log file."
$doIt = Read-Host "Enter 1 to continue"
if (!($doIt -eq 1))
{
return "Script ended. User did not consent."
}
}



#============================ Function SECTION =============================



#------------------------- FUNCTION WRITE-LOG-SUCCESS --------------------------



# Logs success after updating AD Attribute for a given server.



Function write-Log-Success ($server)
{
# Prepare outInfo
$outInfo = $null
$stamp = Get-Date
$time = $stamp.ToString('u')
$ouName = Get-ADComputer $server -Properties * | select CanonicalName
$message = " -- SUCCESS -- Active Directory attribute set"

# Add AD update info to log file
$outInfo = $time + "," + $server + "," + $ouName.CanonicalName + "," + $message + "," + $value
Add-Content -Value $outInfo -Path $logFile
}



#------------------------- FUNCTION WRITE-LOG-FAILURE --------------------------



# Logs failure after trying to update AD Attribute for a given server.



Function write-Log-Failure ($server)
{
# Prepare outInfo
$outInfo = $null
$stamp = Get-Date
$time = $stamp.ToString('u')
$ouName = Get-ADComputer $server -Properties * | select CanonicalName
$message = " -- FAILURE -- Active Directory attribute not set or could not be validated"
$value = "N/A"

# Add AD update info to log file
$outInfo = $time + "," + $server + "," + $ouName.CanonicalName + "," + $message + "," + $value
Add-Content -Value $outInfo -Path $logFile
}



#------------------------- FUNCTION WRITE-LOG-SKIP --------------------------



# Logs that server was skipped.



Function write-Log-Skip ($server)
{
# Prepare outInfo
$outInfo = $null
$stamp = Get-Date
$time = $stamp.ToString('u')
$ouName = Get-ADComputer $server -Properties * | select CanonicalName
$message = " -- Skipped -- Active Directory attribute was untouched by this script. Run a separate script to determine the attribute value for this server."
$value = "N/A"

# Add AD update info to log file
$outInfo = $time + "," + $server + "," + $ouName.CanonicalName + "," + $message + "," + $value
Add-Content -Value $outInfo -Path $logFile
}




#------------------------- GET-ATTRIBUTE-VALUE-FOR-SERVER --------------------------



function get-attribute-value-for-server ($server)
{
# Get Domain
$ouName = Get-ADComputer $server -Properties * | select CanonicalName
$canonicalName = $ouName.CanonicalName
$domain = $canonicalName.split('.')[0]

# Get Operating System
$osNAME = Get-ADComputer $server -Properties * | select OperatingSystem
$os = $osName.OperatingSystem

# Set value
if ($domain -eq "ms")
{
if ($os -match "windows")
{
$value = "Cyberark-O"
}
elseif (($os -match "linux") -or ($os -match "unix"))
{
$value = "Cyberark-UNO"
}
elseif ($server -match "vsme")
{
$value = "Cyberark-EO"
}
else
{
$value = $null
}
}
elseif ($domain -eq "dmzmgmt")
{
if ($os -match "windows")
{
$value = "Cyberark-WTO"
}
}
else
{
$value = $null
}
# Return attribute value
return $value

}



#------------------------- FUNCTION UPDATE-AD-ATTRIBUTE --------------------------



# Takes in a list of servers and updates the AD attribute for each.
# Catches any system exceptions.



function update-AD-Attribute ($serverInventory)
{
foreach ($line in $serverInven)
{
# Get netBiosName column from server inventory
# May have been given FQDN, in which case we split for netBiosName.
# If given netBiosName, split should return netBiosName anyways.
# Just in case we use a catch.
try
{
$server = $line.netBiosName.split('.')[0]
}
catch
{
$server = $line.netBiosName
}

# Set value
if ($singleValue -eq "")
{
$value = get-attribute-value-for-server $server
}
else
{
$value = $singleValue.trim()
}

if (!$value)
{
Write-Warning "Domain or OS not found for $server. See log file for details after validation step."
continue
}

Try
{
write-output "Processing $server..."
Get-ADComputer -Identity $server | Set-ADComputer -Replace @{ 'uht-Cyberark-AutoDetect' = $value }
}

Catch [System.Exception] {
Write-Warning "A system exception occured. Active Directory update may have failed for $server. See log after validation check to determine if this error was fatal."
}
}
}



#------------------------- FUNCTION VALIDATE-AD-ATTRIBUTE --------------------------



# Takes in a list of servers, validates that the AD attribute
# is set to the proper value for each server, then calls the
# logging functions to record if the attribute was set successfully.



function validate-AD-Attribute($serverInven)
{
foreach ($line in $serverInven)
{
# Get netBiosName column from server inventory
# May have been given FQDN, in which case we split for netBiosName.
# If given netBiosName, split should return netBiosName anyways.
# Just in case we use a catch.
try
{
$server = $line.netBiosName.split('.')[0]
}
catch
{
$server = $line.netBiosName
}

# Set value
if ($singleValue -eq "")
{
$value = get-attribute-value-for-server $server
}
else
{
$value = $singleValue.trim()
}

if (!$value)
{
Write-Warning "Failed to grab domain or OS for $server, so could not validate."
write-output "$server will be logged as skipped."
write-Log-Skip $server
continue
}

# Validate that the AD attribute was set successfully
try
{
$validate = Get-ADComputer -Identity $server -Properties 'uht-Cyberark-AutoDetect'
}
catch
{
# Validation failed; set null so failure is logged
$validate = $null
}

if ($validate.'uht-Cyberark-AutoDetect' -eq $value)
{
# Validated, logging results
write-output "Validation SUCCESS for $server"
write-output "Writing to log..."
write-Log-Success $server
}
else
{
# Validation failed, logging results
write-warning "Validation FAILURE for $server"
write-output "Writing to log..."
write-Log-Failure $server
}
}
}



#---------------------------- FUNCTION MAIL-LOG -----------------------------



# Takes in the log file to be mailed and the list of recipients,
# then sends the log file as an attachment to this list.



function mail-Log ($logFile, $addressList)
{
foreach ($mailRecipient in $addressList)
{
# Prepare message contents
$subject = "Active Directory Attribute Bulk Update Log File"
$timestamp = Get-Date
$signature = "`n`nMessage sent via PowerShell Script at $($timestamp.ToString('u')). `n`nFor questions about this log file, contact Asim Chaudhary <asim_chaudhary@optum.com>"
$body = "Hello, `n`nThis message contains the log file for the Active Directory bulk update, setting the uht-Cyberark-AutoDetect attribute.`n$signature"

# Add log file as attachment
$attachment = $logFile

# Send
Send-MailMessage -From "jratliff@optum.com" -To $mailRecipient -Subject $subject -Body $body -SmtpServer mail20.corpmailsvcs.com -Attachments $attachment
write-output "Message sent to $mailRecipient."
}
}



#=========================== MAIN PROCESSING SECTION ============================



# For each server in imported CSV, update the AD attribute
update-AD-Attribute $serverInven
write-output "`nFinished attempting AD attribute updates. Going to sleep for 90 seconds, so updates can take effect."



# 1.5 min break to allow updates to go into effect (set 90 seconds)
Start-Sleep -Seconds 90
write-output "Sleep over *yawn*. Waking up to validate AD attributes."



# For each server in the CSV, validate the AD attribute
validate-AD-Attribute $serverInven
write-output "`nValidation check complete. Mailing log file..."



# Mail log file
mail-Log $logFile $addressList
write-output "Mailing complete."



# Open log file
write-output "Opening log file for local viewing..."
NOTEPAD.EXE $logFile



#========================== Clean Up SECTION ===========================



write-output "$(Get-Date): Script completed!"