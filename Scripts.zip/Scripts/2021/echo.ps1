﻿param(
    [string]$servername, [string]$email
	
)

ipmo VMWare.PowerCLI


Write-Output "hello"
Write-Output $servername
Write-Output $email