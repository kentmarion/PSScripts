﻿#ST-021

$username = "MS\mmend133";
$password = "ny8j9ZD.";

#secondary
#$username = "MS\mmend112"
#$password = 'Oj1$BRWb'

$vCenters = @('mn011h1a0','mn011h1a1','mn011h1a2','mn011h1a3','mn011h1a7','mn011h1a9','mn011h1b0','mn011h1b1','mn011h1b2','mn053h1a0','mn053h1a1','mn053h1a2','mn053h1a3','mn053h1a7','mn053h1a9','mn053h1b0','mn053h1b1','mn053h1b2');

#test vCenters in ODI
$vCenters = @('mn011h1t0','mn011h1t1','mn011h1t2','mn053h1t0','mn053h1t1','mn053h1t2');

foreach ($vCenter in $vCenters){

    $vCenter = $vCenter+".uhc.com";

    #Connect to vCenter
    Connect-VIServer -Server $vCenter -User $username -Password $password;

    #Initiate query
    $query = Get-Datastore * -Server $vCenter | Where-Object {$_.StorageIOControlEnabled -eq $false}

    #Store value for exporting purposes
    $result = $query | select name, StorageIOControlEnabled, datacenter, @{Name='vCenter';Expression={$vCenter}} 
    
    #EnableSIO
    #Set-Datastore -datastore ($query) -StorageIOControlEnabled $true

    #Write-Output $result; #TEST
    #Export results of previous DS with Disabled SIO
    $result | Export-CSV -Path "C:\Users\MMEND111\OneDrive - UHG\Scripts\Enable Storage IO\SIOReport_TEST.csv" -NoTypeInformation -Append

} 

