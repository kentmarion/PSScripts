﻿$username = "MS\veasautoodi";
$password = 'Hubget1t';

$csv = Import-Csv "C:\Users\MMEND111\OneDrive - UHG\Scripts\NTP Scripts\NTP.csv";
$currVCenter = "";

foreach ($line in $csv)
{
    $newVCenter = $line.vCenter;
    $currHost = $line.host+".uhc.com";

    Write-Output $newvCenter;
    Write-Output $currHost;

    if($newVCenter -ne $currVCenter){
        Connect-VIServer -Server $newVCenter -User $username -Password $password;
        $currVCenter = $newVCenter;
    }

    try{
        $allNTPList = Get-VMHostNtpServer -VMHost $currHost

        Get-VMHost $currHost | Remove-VMHostNtpServer -NtpServer $allNTPList -Confirm:$false
        Get-VMHost $currHost | Add-VMHostNtpServer -NtpServer 10.90.40.105,10.1.112.104,10.7.136.103;
        #Get-VMHost $currHost | Add-VMHostNtpServer -NtpServer time1_gv.uhc.com,time1_igs.uhc.com,time1_egn.uhc.com;

        Get-VMHost $currHost | Get-VMHostService | Where-Object {$_.key -eq "ntpd" } | Start-VMHostService;
        Get-VMHost $currHost | Get-VMHostService | Where-Object {$_.key -eq "ntpd" } | Set-VMHostService -policy "automatic";
    }catch{
        $currHost | Out-File C:\Users\MMEND111\Documents\Powershell\NoNTP_Errors.txt -Append;
    }
}
