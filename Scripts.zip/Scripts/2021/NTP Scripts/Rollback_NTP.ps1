﻿$username = "MS\mmend112";
$password = "R0m-Z(6m";

$csv = Import-Csv C:\Users\MMEND111\Documents\Powershell\NoNTP_test.csv;
$currVCenter = "";

foreach ($line in $csv)
{
    $newVCenter = $line.vCenter;
    $currHost = $line.host;

    Write-Output $vCenter;
    Write-Output $currHost;

    if($newVCenter -ne $currVCenter){
        Connect-VIServer -Server $newVCenter -User $username -Password $password;
        $currVCenter = $newVCenter;
    }

    try{
        Get-VMHost $currHost | Remove-VMHostNtpServer -NtpServer * Confirm:$false

    }catch{
        $currHost | Out-File C:\Users\MMEND111\Documents\Powershell\NoNTP_Errors.txt -Append;
    }
}