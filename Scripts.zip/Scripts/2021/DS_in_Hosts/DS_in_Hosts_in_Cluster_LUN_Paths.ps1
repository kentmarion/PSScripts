﻿$CurrentDate = Get-Date
$CurrentDate = $CurrentDate.ToString('MM-dd-yyyy_hh-mm-ss')
$vCenters = Get-Content "C:\Users\MMEND111\OneDrive - UHG\Scripts\DS_in_Hosts\vCenters.txt"
$output = "C:\Users\MMEND111\OneDrive - UHG\Scripts\DS_in_Hosts\Output\Output_Path" + "_" + $CurrentDate + ".csv"

foreach ($vCenter in $vCenters){

    #Check which creds to use
    if($vCenter -like "mn0*") {
        #ODI CREDS
        $username = "MS\mmend133";
        $password = '$0aNInsM';
    }else{
        #SECONDARY CREDS
        $username = "MS\mmend112";
        $password = "CR%Ois1$";
    }

    #Connect to Vcenter
    Connect-VIServer -Server $vCenter -User $username -Password $password
    $filename = "C:\Users\MMEND111\OneDrive - UHG\Scripts\DS_in_Hosts\$vCenter" + ".txt"
    $Clusters = Get-Content $filename


    #Perform queries
    ForEach ($Cluster in $Clusters){

        Get-cluster $Cluster | get-vmhost | ForEach-Object {

            $hostname = $_.name
            $Clustername = $_.Parent

            $esxcli = Get-EsxCli -VMHost $hostname

            #FIBRECHANNEL
            #$hba = Get-VMHostHba -VMHost $esx -Type "FibreChannel" | Select -ExpandProperty Name

            $hba = Get-VMHostHba -VMHost $hostname -Type "ISCSI" | Select -ExpandProperty Name
            #Get-VMHostHba -VMHost $hostname -Type "ISCSI" | Select *

            $esxcli.storage.core.path.list() |
            Where{$hba -contains $_.Adapter} |
            Group-Object -Property Device | Select *
            #Select @{N='vCenter';E={$vCenter}}, @{N='Cluster';E={$Clustername}}, @{N='Host';E={$hostname}}, @{N='LUN';E={$_.Name}},@{N='#Path';E={$_.Group.Count}}

            $result | Export-CSV -Path $output -NoTypeInformation -Append;
        }
    }
}



