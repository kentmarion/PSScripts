﻿$CurrentDate = Get-Date
$CurrentDate = $CurrentDate.ToString('MM-dd-yyyy_hh-mm-ss')

##Change these locations##
$vCenters = Get-Content "C:\Users\MMEND111\OneDrive - UHG\Scripts\DS_in_Hosts\vCenters.txt"
$output = "C:\Users\MMEND111\OneDrive - UHG\Scripts\DS_in_Hosts\Output\OutputVMMonitoring" + "_" + $CurrentDate + ".csv"
##########################

foreach ($vCenter in $vCenters){

    ###Checks which creds to use####
    #CHANGE UR CREDS BEFORE RUNNING#
    if($vCenter -like "mn0*") {
        #ODI CREDS
        $username = "MS\mmend133";
        $password = "MY-U7pEz";
    }else{
        #SECONDARY CREDS
        $username = "MS\mmend112";
        $password = "AV_x62zB";
    }
    ###############################

    #Execute scripts here#
    #Connect to Vcenter
    Connect-VIServer -Server $vCenter -User $username -Password $password

    #Perform query on all clusters inside the vcenter
    $query = Get-Cluster | Select-Object -Property @{N='vCenter';E = {$vCenter}},Name,
    @{N='VMMonitoring';E={$_.ExtensionData.Configuration.DasConfig.vmMonitoring}}

    #Export query and appending them to the new report
    $query | Export-CSV -Path $output -NoTypeInformation -Append;
}