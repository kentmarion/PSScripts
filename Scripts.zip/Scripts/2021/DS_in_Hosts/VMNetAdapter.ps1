﻿$CurrentDate = Get-Date
$CurrentDate = $CurrentDate.ToString('MM-dd-yyyy_hh-mm-ss')

#CHANGE#
$csv = Import-CSV "C:\Users\MMEND111\OneDrive - UHG\Scripts\DS_in_Hosts\VM-005_NetAdapter.csv" 
$output = "C:\Users\MMEND111\OneDrive - UHG\Scripts\DS_in_Hosts\Output\NetAdapter" + "_" + $CurrentDate + ".csv"
########


foreach ($line in $csv)
{
    $newVCenter = $line.vCenter;
    $currVM = $line.vm;

    #Check which creds to use
    if($vCenter -like "mn0*") {
        #ODI CREDS
        $username = "MS\veasautoodi"; 
        $password = 'Hubget1t';    
    }else{
        #SECONDARY CREDS
        $username = "MS\veasauto"; 
        $password = "Hubget1t";    
    }

    $newVCenter = $line.vCenter;

    Write-Output $newvCenter;
    Write-Output $currVM;

    if($newVCenter -ne $currVCenter){
        Connect-VIServer -Server $newVCenter -User $username -Password $password;
        $currVCenter = $newVCenter;
    }

    
    #Perform queries
    try{
        $VMdetails = Get-VM $currVM | Get-VMGuest | select VM, OSFullName, Nics
        $result = Get-VM $currVM | Get-NetworkAdapter | 
        select @{Name='vCenter';Expression={$currVCenter}},
        @{Name='VM';Expression={$VMdetails.VM}},
        @{Name='OS';Expression={$VMdetails.OSFullName}},
        @{Name='NICS';Expression={$VMdetails.Nics}},
        Type

        $result | Export-CSV -Path $output -NoTypeInformation -Append;
    }catch{

        Write-Output "VM $currVM not found."

    }
        
}



