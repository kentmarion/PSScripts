﻿$vCenter = 'mn011h1a2.uhc.com'
$CurrentDate = Get-Date
$output = "C:\Users\MMEND111\Desktop\Output_Path_NAA_sample.csv"

#Connect-VIServer mn011h1a2.uhc.com

#$esxName = 'MyESX'

$esx = 'mn011-5hz1-06s37.uhc.com'

$esxcli = Get-EsxCli -VMHost $esx

#FIBRECHANNEL
#$hba = Get-VMHostHba -VMHost $esx -Type "FibreChannel" | Select -ExpandProperty Name

$hba = Get-VMHostHba -VMHost $esx -Type "ISCSI" | Select -ExpandProperty Name

$result = $esxcli.storage.core.path.list() |
Where{$hba -contains $_.Adapter} |
Group-Object -Property Device |
Select-Object @{N='vCenter';E={$vCenter}}, @{N='Host';E={$esx}}, @{N='LUN';E={$_.Name}},@{N='#Path';E={$_.Group.Count}}

$result | Export-CSV -Path $output -NoTypeInformation -Append

write-output $result