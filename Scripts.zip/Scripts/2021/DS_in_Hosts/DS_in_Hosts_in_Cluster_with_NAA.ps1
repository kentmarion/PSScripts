﻿$CurrentDate = Get-Date
$CurrentDate = $CurrentDate.ToString('MM-dd-yyyy_hh-mm-ss')
$vCenters = Get-Content "C:\Users\MMEND111\OneDrive - UHG\Scripts\DS_in_Hosts\vCenters.txt"
$output = "C:\Users\MMEND111\OneDrive - UHG\Scripts\DS_in_Hosts\Output\Output" + "_" + $CurrentDate + ".csv"

foreach ($vCenter in $vCenters){

    #Check which creds to use
    if($vCenter -like "mn0*") {
        #ODI CREDS
        $username = "MS\veasautoodi";
        $password = "Hubget1t";
    }else{
        #SECONDARY CREDS
        $username = "MS\veasauto";
        $password = "Hubget1t";
    }

    #Connect to Vcenter
    Connect-VIServer -Server $vCenter -User $username -Password $password
    $filename = "C:\Users\MMEND111\OneDrive - UHG\Scripts\DS_in_Hosts\$vCenter" + ".txt"
    $Clusters = Get-Content $filename


    #Perform queries
    ForEach ($Cluster in $Clusters){

        Get-cluster $Cluster | get-vmhost | ForEach-Object {

            $hostname = $_.name
            $Clustername = $_.Parent

            $query = Get-Datastore -VMHost $hostname -Refresh | Select-Object @{Name='vCenter';Expression={$vCenter}}, @{N='Cluster'; E={$Clustername}}, @{N='HostName'; E={$hostname}}, Name, @{N="NAA";E={(Get-ScsiLun -CanonicalName ($_.ExtensionData.Info.Vmfs.Extent[0]).DiskName -VMHost (Get-VIObjectByVIView $_.ExtensionData.Host[0].Key)).ExtensionData.DisplayName}};
            $query | Export-CSV -Path $output -NoTypeInformation -Append;

        }
    }
}