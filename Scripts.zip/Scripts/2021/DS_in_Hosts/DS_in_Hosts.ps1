﻿#ipmo VMWare.PowerCLI

$vCenter = Read-Host -Prompt 'Input VCenter';
Connect-VIServer $vCenter;

do{

$yes = "yes";

    $cluster = Read-Host -Prompt 'Input Cluster Name';
    $vmhosts = Get-Cluster $cluster | Get-VMHost;

    foreach ($vmhost in $vmhosts)
    {
        Get-Datastore -VMHost $vmhost -Refresh | Select-Object * | Export-Csv -Path .\Output\$vmhost.csv -NoTypeInformation;
    }

    $yes = Read-Host -Prompt 'Do you want to input a new cluster? [yes/no]';

}while($yes -eq "yes")