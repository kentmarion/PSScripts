﻿#CHANGE THESE VALUES OR DOUBLE CHECK BEFORE RUNNING#
$csvImportPath = "C:\Users\MMEND111\OneDrive - UHG\Scripts\DS_in_Hosts\Finding_MinimizeDatastoreConfigDiffRule_07-12-2021.csv";
$csvExportPath = "C:\Users\MMEND111\OneDrive - UHG\Scripts\DS_in_Hosts\List_of_DSs_in_Host_in_Cluster.csv";
$userODI = "MS\mmend133"
$passODI = "NZmiu0%s"
$userUCI = "MS\mmend112"
$passUCI = "CR%Ois1$"
####################################################

$csv = Import-Csv $csvImportPath;
$currVCenter = "";

foreach ($line in $csv)
{
    $newVCenter = $line.vCenter;
    $currCluster = $line.Cluster;

    Write-Output $newVCenter;
    Write-Output $currCluster;

    #Check which creds to use

    if($newVCenter.length -eq 17){
        #ODI CREDS
        $username = $userODI;
        $password = $passODI;
    }else{
        #SECONDARY CREDS
        $username = $userUCI;
        $password = $passUCI;
    }
    
    #Connect to Vcenter

    if($newVCenter -ne $currVCenter){
        Connect-VIServer -Server $newVCenter -User $username -Password $password;
        $currVCenter = $newVCenter;
    }
    
    $vmHosts = Get-Cluster $currCluster | Get-VMHost;
    foreach ($vmHost in $vmHosts)
    {
        $query = Get-Datastore -VMHost $vmHost -Refresh | Select-Object @{Name='vCenter';Expression={$currVCenter}}, @{N='Host'; E={$vmHost}}, Name, @{N="DisplayName";E={(Get-ScsiLun -CanonicalName ($_.ExtensionData.Info.Vmfs.Extent[0]).DiskName -VMHost (Get-VIObjectByVIView $_.ExtensionData.Host[0].Key)).ExtensionData.DisplayName}};
        $query | Export-CSV -Path $csvExportPath -NoTypeInformation -Append;
    }
}