#!/usr/bin/python

import json
import requests
import pandas as pd
import subprocess
import KeyPoints

### Author : Hemant Gupta (Unix Build)
### Username and Password

username = KeyPoints.usernameforSNOW
password = KeyPoints.passwordforSNOW


### Headers

gheaders = {"Content-Type":"application/json","Accept":"application/json"}


### Create node incident --> to be worked /not assigned to anyone in unix build  and OGS queue

gurl = "https://optumstage.service-now.com/api/now/table/incident?sysparm_query=active%3Dtrue%5Eassignment_group%3D0928f4e5db6f470854f8790aaf9619ff%5Estate%3D1%5EdescriptionNOT%20LIKEManual%20Intervention%20Required%5Eassigned_toISEMPTY&sysparm_display_value=true&sysparm_exclude_reference_link=True&sysparm_fields=number%2Cshort_description%2Cdescription"

### Get Response from get URL

gresponse = requests.get(gurl, auth=(username, password), headers=gheaders)
resp=gresponse.json()

### Putting data in dataframe

for key in resp:
        data = resp[key]

df = pd.DataFrame(data)


### Accessing data from incident one by one

for ind in df.index:
                incno = df["number"][ind]
                short_descr = df["short_description"][ind]
                descr = df["description"][ind].strip()
### Fetching out details from servers
                if '/tmp exceeds 95%' in short_descr:
                        subprocess.call('/home/hgupta8/update_inc.py {0} "{1}" '.format(incno, descr),shell=True)
			subprocess.call("echo 'Ticket Recieved' | mail -s 'incident received for /tmp %s' hemant_gupta57@optum.com"%incno,shell=True)
                else:
                        pass

