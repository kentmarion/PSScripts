#!/usr/bin/python

import json
import requests
import pandas as pd
import re
import subprocess
import datetime
import os
import KeyPoints

### Author : Hemant Gupta (Unix Build)
### Username and Password

username = KeyPoints.usernameforSNOW
password = KeyPoints.passwordforSNOW


### Headers

gheaders = {"Content-Type":"application/json","Accept":"application/json"}

### Create node incident --> to be worked /not assigned to anyone in unix build  and OGS queue

gurl = "https://optumstage.service-now.com/api/now/table/incident?sysparm_query=active%3Dtrue%5Eassignment_group%3D0928f4e5db6f470854f8790aaf9619ff%5EdescriptionNOT%20LIKEManual%20Intervention%20Required%5Eassigned_to%253D8be6ae5f1b3b8c10f345c99f1d4bcb2e%26&sysparm_display_value=true&sysparm_exclude_reference_link=True&sysparm_fields=number%2Cshort_description%2Cdescription%2Copened_at"

### Get Response from get URL

gresponse = requests.get(gurl, auth=(username, password), headers=gheaders)
resp=gresponse.json()

### Putting data in dataframe

for key in resp:
        data = resp[key]

df = pd.DataFrame(data)


### Accessing data from incident one by one

for ind in df.index:
        incno = df["number"][ind]
        short_descr = df["short_description"][ind]
        descr = df["description"][ind]
### Fetching out details from servers
        if '/tmp exceeds 95%' in short_descr:
                server_name =  re.split("Severity",descr)[0].split(" ")[8].strip()
                today_date = datetime.datetime.today()
		opened_date =  re.split("Time",descr)[1].split(": ")[1].strip()
                opened_date = datetime.datetime.strptime(opened_date,'%Y-%m-%d %H:%M:%S')
                SLA_date = opened_date + datetime.timedelta(days=3)
                if today_date <= SLA_date:
			SLA_date = str(SLA_date.date())
### Pass arguments to script to send notification to cutomer if less than 3 days of ticket arrival

			subprocess.call('/home/hgupta8/cp.py {0} {1} {2} "{3}"'.format(incno, server_name, SLA_date, descr),shell=True)
                else:
### Pass arguments to script to clean /tmp and close the incident if more than 3 days of ticket arrival
                	
			subprocess.call('/home/hgupta8/remove_files.py {0} {1} {2} "{3}"'.format(incno, server_name, SLA_date, descr),shell=True)
        else:
                pass

