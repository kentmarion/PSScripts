#!/usr/bin/python
import json
import requests
import pandas as pd
import re
import subprocess
import sys
import datetime
import KeyPoints

### Author : Hemant Gupta (Unix Build)
### Username and Password

username = KeyPoints.usernameforSNOW
password = KeyPoints.passwordforSNOW


posturl = 'https://optumstage.service-now.com/api/now/import/u_incident'
inc_number = sys.argv[1]
descr = sys.argv[2]
today_date = str(datetime.datetime.today().strftime("%Y-%m-%d %H:%M:%S"))

descr = descr + "\n" + "Self-Heal Start Time: " + today_date



gheaders = {"Content-Type":"application/json","Accept":"application/json"}
pheaders = {"sysparm_display_value":"true","Content-Type":"application/json","Accept":"application/json"}

def inc_update(inc_number,worknotes,state,category,priority,assigned_to,descr):
    update = {"number": inc_number, "work_notes": worknotes, "state": state,"u_type": category, "priority": priority,"assigned_to": assigned_to,"description": descr}
    update_response = requests.post(posturl, auth=(username, password), headers=pheaders, data=json.dumps(update))
    updateresp=update_response.json()
    print(updateresp)

#Assign Incident to integration user id to avoid queue manager to pick it up and change priority to 5

inc_update(inc_number,"Self-Heal will now start","5","Service Request","5","700001588",descr)

