#!/usr/bin/python
import json
import requests
import pandas as pd
import re
import subprocess
import sys
import KeyPoints

### Author : Hemant Gupta (Unix Build)
### Username and Password

username = KeyPoints.usernameforSNOW
password = KeyPoints.passwordforSNOW


posturl = 'https://optumstage.service-now.com/api/now/import/u_incident'
inc_number = sys.argv[1]
servername = sys.argv[2]
SLA_date = sys.argv[3]
descr = sys.argv[4]

gheaders = {"Content-Type":"application/json","Accept":"application/json"}
pheaders = {"sysparm_display_value":"true","Content-Type":"application/json","Accept":"application/json"}

def inc_update(inc_number,worknotes,state,category,priority):
    update = {"number": inc_number, "work_notes": worknotes, "state": state,"u_type": category, "priority": priority}
    update_response = requests.post(posturl, auth=(username, password), headers=pheaders, data=json.dumps(update))
    updateresp=update_response.json()
    print(updateresp)

def inc_close(inc_number, inc_state,cmdb,comments,close_code, close_notes):
    close = {"number": inc_number, "state": inc_state,"cmdb_ci": cmdb,"comments": comments, "close_code": close_code, "close_notes": close_notes,"assigned_to":""}
    close_response = requests.post(posturl, auth=(username, password), headers=pheaders, data=json.dumps(close))
    close_resp = close_response.json()
    print(close_resp)

def Manual_intervention(inc_number,inc_state,worknotes,descr):
    descr = 'Manual Intervention Required : '+ descr
    update = {"number": inc_number, "work_notes": worknotes,"assigned_to":"","description":descr}
    update_response = requests.post(posturl, auth=(username, password), headers=pheaders, data=json.dumps(update))
    updateresp=update_response.json()
    print(updateresp)

outputfromscr = subprocess.call('scp -qrp -i /home/p1054/python_scripts/Service-now/id_rsa -o StrictHostKeyChecking=no -o "proxycommand ssh -q -W %h:%p -o StrictHostKeyChecking=no root@apsrp05941" /home/hgupta8/script root@{0}:/tmp/'.format(servername),shell=True)



## Run the script to get size of /tmp and details of files/dir which are holding up large space

outputfromscr = subprocess.check_output('ssh -q -i /home/p1054/python_scripts/Service-now/id_rsa root@{0} -o StrictHostKeyChecking=no -o "proxycommand ssh -q -W %h:%p -o StrictHostKeyChecking=no root@apsrp05941" "bash /tmp/script"'.format(servername),shell=True)


if 'closing the incident' in outputfromscr:
        status = outputfromscr
        inc_close(inc_number,"7",servername,status,"Solved/Solution Provided","Closed as utlization under threshold ")
elif 'NOTIFICATION' in outputfromscr:
        status = outputfromscr

### Get server owner details from oasis

	out = subprocess.check_output("curl -s http://oasis.uhc.com:9098/OASISServerInfo.svc/MultiSystemContactInfo?DeviceName=apvrd54364 |xmllint --format - |grep Email|grep -v 'andrew.zianio'|cut -d '>' -f2|cut -d '<' -f1|sort -n|uniq |grep '\S'|tr '\r\n' ' '",shell=True)
	out = out + " OGS-GlobalProvisioningTeam_DL@ds.uhc.com"

### Send email to customers and OGS for notification

	output = subprocess.check_output("echo '{0}'| mail -s '{3} /tmp is full , files will be cleared on {2}' {1}".format(status, out, SLA_date, inc_number),shell=True)
	inc_update(inc_number,status,"5","Service Request","5")
else:
	descr = 'Manual Intervention Required : '+ descr
        Manual_intervention(inc_number,"1","Manual Intervention Required",descr)


