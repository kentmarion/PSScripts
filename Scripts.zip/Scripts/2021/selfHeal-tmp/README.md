# selfHeal-tmp

Self-Healting for /tmp focuses to resolve incidents coming to OGS(Optum General Systems) queue for servers crossing the threshold limit of 95% utilization of space on /tmp file system.

A cron job on management server checks for incidents assigned to OGS queue for description that matches /tmp more than 95% and starts working on it , It aims not only to clean the filesystem but to notify the server owners as well so as to give them a buffer time to move things which are important to them to some secure location.

The flow is explained in the below flow diagram:

![alt text](images/Flow_Diag.PNG)

Platform : Linux servers

Maintainer : Hemant Gupta (hemant_gupta57@optum.com)

Issues : https://github.optum.com/EHS-DCT/selfHeal-tmp/issues
