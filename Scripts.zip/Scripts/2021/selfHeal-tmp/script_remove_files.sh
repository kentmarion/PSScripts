#!/bin/bash

total_size=`df -m /tmp|awk '{print $2}'|tail -1`

th_size=$(( ($total_size*80)/100 ))
curr_size=`df -m /tmp|awk '{print $3}'|tail -1`

if [[ $curr_size -gt $th_size ]];then


rq_size=$(( ($total_size*20)/100 ))


top_files=1
sum_size=0

while [ $sum_size -lt $rq_size ]
do

        for j in `du -sm /tmp/*|sort -nr|head -$top_files|awk '{print $1}'`

        do
                sum_size=$(( $sum_size+$j ))
        done


        top_files=$(( $top_files+1 ))
done

top_files=$(( $top_files-1 ))

for i in `du -sm /tmp/*|sort -nr|head -$top_files`
do
        rm -rf $i
done

curr_size_new=`df -m /tmp|awk '{print $3}'|tail -1`

if [[ $curr_size_new -lt $th_size ]];then

echo "Current utilization is less than the threshold limit, closing the incident"

else

echo "manual intervention required"
echo $curr_size_new
fi

else

echo "Current utilization is less than the threshold limit, closing the incident"
echo $curr_size
fi
