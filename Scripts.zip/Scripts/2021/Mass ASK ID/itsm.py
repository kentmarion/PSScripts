#!C:\Users\MMEND111\AppData\Local\Continuum\Anaconda3\envs\python\python.exe
print("Content-Type: text/html\n")

import requests
import cgi
import json
import codecs
import logging
import subprocess
from subprocess import call
import csv

#GET TOKEN
headers = {
  'accept': 'application/json',
  'Content-Type': 'application/json',
}

data = '{ "msid": "svc_myToken", "password": "Token123!"}'

response = requests.post("https://cloudops-api.optum.com/auth/login", headers=headers, data=data, verify=False)

resp = response.json()
myToken = resp["token"]

with open('6.0.0_EOS.csv', newline='') as f:
  reader = csv.reader(f)
  data = list(reader)

header = ['vm','ask_id']
csv_data = []

for server_name in data:
  server = server_name[5]
  print(server)

  #PROCESS SERVERNAME TO QUERY
  baseURL = "https://cloudops-api.optum.com"
  endPoint = "/api/itsm/cidetails/"+server
  fullURL =  baseURL+endPoint

  #print (fullURL)

  headers2 = {
    'accept': 'application/json',
    'X-API-KEY': myToken
  }

  try:
    # get data from API
    response = requests.get(fullURL, headers=headers2, verify=False)

    saveJSON = response.json()
    ask_id = saveJSON['cidetails_itsm'][0]['app_details']['ask_id']

  except:
    ask_id = 'NO ASK ID'
  
  finally:
    print(server)
    print(ask_id)

    row = [server,ask_id]
    csv_data.append(row)
  
#WRITE REPORT
with open('output.csv', 'w', encoding='UTF8', newline='') as f:
    writer = csv.writer(f)

    # write the header
    writer.writerow(header)

    # write multiple rows
    writer.writerows(csv_data)



