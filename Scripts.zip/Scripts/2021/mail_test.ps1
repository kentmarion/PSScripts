﻿# Prepare message contents
$subject = "TEST EMAIL"
$timestamp = Get-Date
$signature = "`n`nMessage sent via PowerShell Script at $($timestamp.ToString('u')). `n`nFor questions about this log file, contact Floro <floro_escalona@optum.com>"
$body = "Hello, `n`nThis message contains the log file for the Active Directory bulk update, setting the uht-Cyberark-AutoDetect attribute.`n$signature"

# Add log file as attachment
#$attachment = $logFile

# Send

$mailRecipient = "floro_escalona@optum.com";

Send-MailMessage -From "vmware_webmaster@optum.com" -To $mailRecipient" -Subject $subject -Body $body -SmtpServer mail20.corpmailsvcs.com
write-output "Message sent to $mailRecipient

#59e61b85.uhgazure.onmicrosoft.com@amer.teams.ms