#!C:\Users\MMEND111\AppData\Local\Continuum\Anaconda3\envs\python\python.exe
print("Content-Type: text/html\n")

import requests
import cgi
import json
import codecs
import logging
import subprocess
from subprocess import call

#GET TOKEN
headers = {
  'accept': 'application/json',
  'Content-Type': 'application/json',
}

data = '{ "msid": "svc_myToken", "password": "Token123!"}'

response = requests.post("https://cloudops-api.optum.com/auth/login", headers=headers, data=data, verify=False)

resp = response.json()
myToken = resp["token"]

#GET SERVER NAME ENTRY FROM FORM
form = cgi.FieldStorage()
server_name = form.getvalue('server')

#PROCESS SERVERNAME TO QUERY
baseURL = "https://cloudops-api.optum.com"
endPoint = "/api/itsm/cidetails/"+server_name
fullURL =  baseURL+endPoint

#print (fullURL)

headers2 = {
  'accept': 'application/json',
  'X-API-KEY': myToken
}

response = requests.get(fullURL, headers=headers2, verify=False)
if response.status_code==200: #SUCCESS
  saveJSON = response.json()
#print (saveJSON)
#print (response.json())

try:
    # get data from API
    # variables in alphabetical order
    ask_id = saveJSON['cidetails_itsm'][0]['app_details']['ask_id']

except:

    ask_id = ''

finally:
  print("Servername: " + servername)
  print("ASKID: " + ask_id)

