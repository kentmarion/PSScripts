﻿ipmo VMware.PowerCLI

$username = "MS\mmend133"
$password = "%*2CqKyb"

$csv = Import-CSV ""

Connect-VIServer mn053h1b2.uhc.com -username $username -Password $password

$vm = "wn000027964"

$powerstate = get-vm $vm | select PowerState

if($powerstate.PowerState -eq "PoweredOn"){

    Stop-VM -VM $vm -Kill -Confirm:$false

}

Set-VM $vm -GuestId otherLinuxGuest -Confirm:$false

if($powerstate.PowerState -eq "PoweredOff"){

    Start-VM -VM $vm -Confirm:$false

}


#Check All Guest Identifier list
[System.Enum]::GetNames([VMware.Vim.VirtualMachineGuestOsIdentifier])
