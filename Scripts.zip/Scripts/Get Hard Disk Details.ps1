﻿#Connect-VIServer mn053h1a2.uhc.com

$vhd_query = Get-VM 'dbsep6397' | Get-HardDisk | 
Select @{N='VM';E={$_.Parent.Name}},

  @{N='VM Uuid';E={$_.Parent.ExtensionData.Config.Uuid}},

  Name,

  Filename,

  CapacityGB,

  @{N='VMDK_UUID';E={$_.ExtensionData.Backing.Uuid}},

   @{N='SCSI_ID';E={

   $hd = $_

   $ctrl = $hd.Parent.Extensiondata.Config.Hardware.Device | where{$_.Key -eq $hd.ExtensionData.ControllerKey}

   "$($ctrl.BusNumber);$($_.ExtensionData.UnitNumber)"

   }},

   @{N='Controller #';E={(Get-ScsiController -HardDisk $_).UnitNumber}}




Write-Output $vhd_query
  
$vhd_query | Export-CSV -Path "C:\Users\MMEND111\Desktop\DBSEP6397_HardDisk_Details.csv" -NoTypeInformation